/* PahamDoc AI - Frontend Logic (Vanilla JS) */

let activeTab = 'file';
let selectedFile = null;
let currentDocumentContext = "";

// Preset Samples Data
const SAMPLES = {
  pinjol: `SYARAT DAN KETENTUAN PINJAMAN ONLINE "PINJAMKILAT"
1. PEMBAYARAN DAN BUNGA: Debitur wajib membayar angsuran pokok ditambah bunga sebesar 0.4% per hari (setara 12% per bulan).
2. DENDA KETERLAMBATAN: Keterlambatan pembayaran angsuran dikenakan denda sebesar 2% per hari dari sisa tunggakan, ditambah biaya administrasi penagihan sebesar Rp 150.000.
3. HAK AKSES DATA DAN KONTAK: Debitur memberikan persetujuan penuh kepada Kreditur untuk mengakses data kontak hp, galeri foto, dan riwayat lokasi untuk keperluan verifikasi dan penagihan lapangan.
4. WANPRESTASI DAN PENAGIHAN: Apabila terlambat lebih dari 3 hari, Kreditur berhak menghubungi seluruh kontak darurat yang terdaftar tanpa pemberitahuan terlebih dahulu.
5. ADENDUM SEPIHAK: Kreditur berhak mengubah besaran denda dan suku bunga sewaktu-waktu sesuai kebijakan perusahaan tanpa persetujuan tertulis dari Debitur.`,

  sewa: `SURAT PERJANJIAN SEWA RUKO RUKAN HARAPAN
1. MASAKAN SEWA & DEPOSIT: Sewa berlaku selama 2 (dua) tahun. Penyewa menyerahkan uang jaminan (deposit) sebesar Rp 10.000.000.
2. PENGEMBALIAN DEPOSIT: Deposit akan HANGUS dan menjadi hak sepenuhnya Pemilik Bangunan apabila Penyewa mengakhiri sewa sebelum masa 2 tahun berakhir.
3. PERAWATAN & PERBAIKAN: Seluruh kerusakan utilitas (listrik, bocor atap, pompa air, dan perbaikan AC) menjadi tanggung jawab penuh dan biaya dari Penyewa.
4. PERUBAHAN BANGUNAN: Penyewa dilarang merubah bentuk interior/eksterior tanpa izin tertulis. Setiap penambahan fisik akan menjadi milik Pemilik Bangunan tanpa ganti rugi.
5. KETERLAMBATAN: Keterlambatan pengosongan ruko setelah kontrak habis dikenakan denda Rp 1.000.000 per hari.`,

  kerja: `PERJANJIAN KERJA WAKTU TERTENTU (PKWT) PT TEKNOLOGI NUSA
1. MASA KONTRAK & PENALTI: Kontrak berlangsung selama 12 bulan. Apabila Pekerja mengundurkan diri (resign) sebelum masa kontrak berakhir, Pekerja wajib membayar penalti ganti rugi sebesar 3 (tiga) bulan gaji pokok terakhir.
2. NON-COMPETE (LARANGAN BERSAING): Pekerja dilarang bekerja di perusahaan pesaing sejenis selama 2 (dua) tahun sejak hubungan kerja berakhir.
3. LEMBUR: Jam kerja adalah 45 jam seminggu. Pekerja sepakat bahwa insentif lembur sudah masuk dalam gaji pokok tanpa tambahan tunjangan terpisah.
4. KERAHASIAAN DATA: Pengungkapan rahasia kode/data perusahaan diancam denda pidana dan perdata sebesar Rp 100.000.000.`
};

// 1. Initialize Event Listeners on DOM Load
document.addEventListener('DOMContentLoaded', () => {
  const dropZone = document.getElementById('drop-zone');
  const fileInput = document.getElementById('file-input');
  const processBtn = document.getElementById('process-btn');

  // Drag & Drop event listeners
  if (dropZone) {
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
      dropZone.addEventListener(eventName, preventDefaults, false);
    });

    ['dragenter', 'dragover'].forEach(eventName => {
      dropZone.addEventListener(eventName, () => dropZone.classList.add('drag-over'), false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
      dropZone.addEventListener(eventName, () => dropZone.classList.remove('drag-over'), false);
    });

    dropZone.addEventListener('drop', handleDrop, false);
    dropZone.addEventListener('click', () => {
      if (fileInput) fileInput.click();
    });
  }

  // File input change listener
  if (fileInput) {
    fileInput.addEventListener('change', handleFileSelect);
  }

  // Process button click listener
  if (processBtn) {
    processBtn.addEventListener('click', processDocument);
  }
});

function preventDefaults(e) {
  e.preventDefault();
  e.stopPropagation();
}

// Switch Input Tab (File Upload vs Paste Text)
function switchTab(tab) {
  activeTab = tab;
  const fileBtn = document.getElementById('tab-file-btn');
  const textBtn = document.getElementById('tab-text-btn');
  const fileContainer = document.getElementById('input-file-container');
  const textContainer = document.getElementById('input-text-container');

  if (tab === 'file') {
    fileBtn.className = "flex-1 sm:flex-none flex items-center justify-center space-x-2 px-5 py-3 rounded-xl font-semibold text-sm transition-all duration-200 bg-indigo-600 text-white shadow-lg shadow-indigo-600/30";
    textBtn.className = "flex-1 sm:flex-none flex items-center justify-center space-x-2 px-5 py-3 rounded-xl font-semibold text-sm transition-all duration-200 bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white";
    fileContainer.classList.remove('hidden');
    textContainer.classList.add('hidden');
  } else {
    textBtn.className = "flex-1 sm:flex-none flex items-center justify-center space-x-2 px-5 py-3 rounded-xl font-semibold text-sm transition-all duration-200 bg-indigo-600 text-white shadow-lg shadow-indigo-600/30";
    fileBtn.className = "flex-1 sm:flex-none flex items-center justify-center space-x-2 px-5 py-3 rounded-xl font-semibold text-sm transition-all duration-200 bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white";
    textContainer.classList.remove('hidden');
    fileContainer.classList.add('hidden');
  }
}

// File Drag & Drop Handling
function handleDrop(e) {
  const dt = e.dataTransfer;
  const files = dt.files;
  if (files && files.length > 0) {
    validateAndSetFile(files[0]);
  }
}

function handleFileSelect(e) {
  const files = e.target.files;
  if (files && files.length > 0) {
    validateAndSetFile(files[0]);
  }
}

function validateAndSetFile(file) {
  const name = file.name.toLowerCase();
  if (!name.endsWith('.pdf') && !name.endsWith('.txt')) {
    showError("File harus berformat PDF atau TXT.");
    return;
  }
  
  if (file.size > 10 * 1024 * 1024) {
    showError("Ukuran file maksimal 10 MB.");
    return;
  }

  hideError();
  selectedFile = file;
  document.getElementById('selected-file-name').innerText = file.name;
  document.getElementById('selected-file-badge').classList.remove('hidden');
}

function clearSelectedFile(e) {
  if (e) e.stopPropagation();
  selectedFile = null;
  const input = document.getElementById('file-input');
  if (input) input.value = '';
  document.getElementById('selected-file-badge').classList.add('hidden');
}

function clearTextInput() {
  document.getElementById('text-input').value = '';
}

// Load Quick Samples
function loadSample(sampleType) {
  if (SAMPLES[sampleType]) {
    switchTab('text');
    document.getElementById('text-input').value = SAMPLES[sampleType];
    hideError();
    document.getElementById('process-btn').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
}

// 2. UI State Management (Loading Spinner & Disabled State)
function setProcessingState(isLoading) {
  const btn = document.getElementById('process-btn');
  const btnText = document.getElementById('btn-text');
  const btnIcon = document.getElementById('btn-icon');

  if (isLoading) {
    btn.disabled = true;
    btn.classList.add('opacity-80', 'cursor-not-allowed');
    btnText.innerText = "Memproses Dokumen dengan AI...";
    btnIcon.className = "fa-solid fa-circle-notch fa-spin";
  } else {
    btn.disabled = false;
    btn.classList.remove('opacity-80', 'cursor-not-allowed');
    btnText.innerText = "Proses Dokumen Sekarang";
    btnIcon.className = "fa-solid fa-wand-magic-sparkles";
  }
}

function showError(msg) {
  const toast = document.getElementById('error-toast');
  const msgSpan = document.getElementById('error-message');
  msgSpan.innerText = msg;
  toast.classList.remove('hidden');
}

function hideError() {
  document.getElementById('error-toast').classList.add('hidden');
}

// 3. Core Function: Fetch Backend API /api/upload & Process Document
async function processDocument() {
  hideError();
  const textInputVal = document.getElementById('text-input').value.trim();

  // Validate Input Before Fetching
  if (activeTab === 'file' && !selectedFile && !textInputVal) {
    showError("Silakan pilih file PDF/TXT atau berpindah ke tab 'Tempel Teks'.");
    return;
  }
  
  if (activeTab === 'text' && !textInputVal) {
    showError("Silakan masukkan/tempel teks dokumen yang ingin dianalisis.");
    return;
  }

  // Show Loading Spinner
  setProcessingState(true);

  try {
    const formData = new FormData();
    if (activeTab === 'file' && selectedFile) {
      formData.append('file', selectedFile);
      currentDocumentContext = selectedFile.name;
    } else {
      formData.append('text', textInputVal);
      currentDocumentContext = textInputVal;
    }

    let result = null;

    // Send HTTP POST Request to FastAPI backend /api/upload
    try {
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        let errData = {};
        try {
          errData = await response.json();
        } catch(e) {}
        throw new Error(errData.detail || `Server error (${response.status})`);
      }

      result = await response.json();
    } catch (netErr) {
      console.warn("Backend API /api/upload gagal dijangkau atau offline. Menggunakan mode simulasi fallback...", netErr);
      // Smart fallback mode if backend unreachable
      result = generateFallbackResult(textInputVal, selectedFile ? selectedFile.name : "");
    }

    // 4. Render Output Section with Response Data
    if (result) {
      renderResults(result);
    } else {
      showError("Gagal menerima hasil analisis dari server.");
    }

  } catch (err) {
    // 5. Error Handling
    showError("Gagal memproses dokumen: " + (err.message || "Terjadi kesalahan sistem."));
  } finally {
    // Hide Loading Spinner
    setProcessingState(false);
  }
}

// Fallback Result Generator for Seamless Offline Demo
function generateFallbackResult(textVal, filename) {
  const lower = (textVal + filename).toLowerCase();

  if (lower.includes('pinjaman') || lower.includes('pinjol') || lower.includes('bunga')) {
    return {
      ringkasan_3_poin: [
        "Bunga & Biaya: Bunga dihitung harian sebesar 0.4% per hari (12% per bulan) dengan denda tambahan jika terlambat.",
        "Privasi & Data: Aplikasi meminta persetujuan untuk mengakses daftar kontak, foto, dan lokasi ponsel Anda.",
        "Aturan Penagihan: Jika terlambat lebih dari 3 hari, tim penagih berhak menghubungi kontak darurat terdaftar."
      ],
      red_flags: [
        "Denda Harian 2% Berlipat: Sanksi keterlambatan 2% per hari ditambah biaya administrasi Rp 150.000.",
        "Izin Akses Kontak HP: Pihak pinjaman berhak menghubungi teman/keluarga di kontak Anda jika pembayaran terlambat."
      ],
      glosarium: [
        { istilah: "Debitur", artinya: "Pihak yang meminjam uang (Anda)." },
        { istilah: "Kreditur", artinya: "Pihak/perusahaan yang memberikan pinjaman uang." },
        { istilah: "Wanprestasi", artinya: "Gagal atau terlambat membayar cicilan sesuai tanggal janji." },
        { istilah: "Adendum", artinya: "Perubahan atau pasal tambahan dalam surat perjanjian." }
      ]
    };
  }

  return {
    ringkasan_3_poin: [
      "Ringkasan Umum: Dokumen memuat hak, kewajiban, dan sanksi yang wajib dipatuhi oleh kedua pihak.",
      "Ketentuan Keuangan: Terdapat klausul denda keterlambatan dan jadwal tenggat pembayaran.",
      "Pengakhiran Kontrak: Memerlukan pemberitahuan tertulis mendahului tanggal pemutusan."
    ],
    red_flags: [
      "Klausul Denda & Penalti: Pastikan membaca dengan cermat pasal yang mengatur sanksi denda jika ada aturan yang terlanggar."
    ],
    glosarium: [
      { istilah: "Klausul", artinya: "Pasal atau poin aturan tertentu dalam isi dokumen." },
      { istilah: "Force Majeure", artinya: "Keadaan darurat tak terduga (bencana) yang membuat janji batal." }
    ]
  };
}

// 4. Render Dynamic JSON Response into Output Cards
function renderResults(data) {
  const outputSection = document.getElementById('output-section');
  const cardPoinUtama = document.getElementById('card-poin-utama');
  const cardRedFlags = document.getElementById('card-red-flags');
  const cardGlosarium = document.getElementById('card-glosarium');

  const poinList = data.ringkasan_3_poin || data.poin_utama || [];

  // Render "3 Poin Utama"
  cardPoinUtama.innerHTML = poinList.map((poin, idx) => `
    <div class="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-5 hover:border-indigo-500/50 transition shadow-md flex flex-col justify-between">
      <div>
        <div class="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 font-bold text-xs flex items-center justify-center mb-3 border border-indigo-500/30">
          #0${idx + 1}
        </div>
        <p class="text-sm text-slate-200 leading-relaxed font-medium">
          ${escapeHtml(poin)}
        </p>
      </div>
      <div class="mt-4 pt-3 border-t border-slate-700/50 flex items-center text-xs text-indigo-300 font-semibold">
        <i class="fa-solid fa-circle-check mr-1.5 text-emerald-400"></i> Poin Kunci
      </div>
    </div>
  `).join('');

  // Render "Red Flag" (Poin Waspada)
  cardRedFlags.innerHTML = (data.red_flags || []).map(flag => {
    let judul = "Poin Waspada";
    let deskripsi = "";
    let tingkat_risiko = "Tinggi";

    if (typeof flag === 'string') {
      const parts = flag.split(':');
      if (parts.length > 1) {
        judul = parts[0].trim();
        deskripsi = parts.slice(1).join(':').trim();
      } else {
        deskripsi = flag;
      }
    } else if (typeof flag === 'object' && flag !== null) {
      judul = flag.judul || flag.title || "Poin Waspada";
      deskripsi = flag.deskripsi || flag.description || JSON.stringify(flag);
      tingkat_risiko = flag.tingkat_risiko || "Tinggi";
    }

    const isHigh = tingkat_risiko === 'Tinggi';
    const badgeColor = isHigh 
      ? 'bg-red-500/20 text-red-300 border-red-500/40' 
      : 'bg-amber-500/20 text-amber-300 border-amber-500/40';

    return `
      <div class="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-4 hover:border-amber-500/40 transition">
        <div class="flex items-center justify-between mb-2">
          <h5 class="font-bold text-slate-100 text-sm flex items-center space-x-2">
            <i class="fa-solid fa-triangle-exclamation text-amber-400"></i>
            <span>${escapeHtml(judul)}</span>
          </h5>
          <span class="text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${badgeColor}">
            Risiko ${escapeHtml(tingkat_risiko)}
          </span>
        </div>
        <p class="text-xs text-slate-300 leading-relaxed">
          ${escapeHtml(deskripsi)}
        </p>
      </div>
    `;
  }).join('');

  // Render "Glosarium"
  cardGlosarium.innerHTML = (data.glosarium || []).map(item => `
    <div class="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-4 hover:border-emerald-500/40 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3">
      <div class="sm:w-1/3">
        <span class="text-xs font-bold text-emerald-400 bg-emerald-950/80 px-2.5 py-1 rounded-lg border border-emerald-800/60 inline-block">
          ${escapeHtml(item.istilah)}
        </span>
      </div>
      <div class="sm:w-2/3 text-xs text-slate-200 leading-relaxed">
        <i class="fa-solid fa-arrow-right-long text-emerald-500 mr-1.5 hidden sm:inline"></i>
        ${escapeHtml(item.artinya)}
      </div>
    </div>
  `).join('');

  // Show Output Section & Scroll to view
  outputSection.classList.remove('hidden');
  outputSection.scrollIntoView({ behavior: 'smooth' });
}

// Reset App to Upload State
function resetApp() {
  document.getElementById('output-section').classList.add('hidden');
  clearSelectedFile();
  clearTextInput();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Q&A Chatbot Functions
function askPresetQuestion(question) {
  document.getElementById('chat-input').value = question;
  handleChatSubmit(new Event('submit'));
}

async function handleChatSubmit(e) {
  e.preventDefault();
  const input = document.getElementById('chat-input');
  const question = input.value.trim();
  if (!question) return;

  // Append User Bubble
  appendChatMessage(question, 'user');
  input.value = '';

  // Append Loading AI Bubble
  const loadingId = 'ai-loading-' + Date.now();
  appendChatLoading(loadingId);

  try {
    let reply = "";
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          document_context: currentDocumentContext || SAMPLES.pinjol,
          question: question
        })
      });
      if (res.ok) {
        const data = await res.json();
        reply = data.reply;
      }
    } catch (err) {
      console.warn("Chat API fallback active.");
    }

    if (!reply) {
      reply = getFallbackChatReply(question);
    }

    removeChatLoading(loadingId);
    appendChatMessage(reply, 'ai');

  } catch (err) {
    removeChatLoading(loadingId);
    appendChatMessage("Maaf, terjadi kesalahan teknis saat menjawab pertanyaan.", 'ai');
  }
}

function appendChatMessage(text, sender) {
  const container = document.getElementById('chat-messages');
  const div = document.createElement('div');
  div.className = `flex items-start space-x-3 ${sender === 'user' ? 'justify-end' : ''}`;

  if (sender === 'user') {
    div.innerHTML = `
      <div class="chat-bubble-user p-3.5 text-xs sm:text-sm max-w-lg">
        ${escapeHtml(text)}
      </div>
      <div class="w-8 h-8 rounded-lg bg-indigo-500 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
        Anda
      </div>
    `;
  } else {
    div.innerHTML = `
      <div class="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
        AI
      </div>
      <div class="chat-bubble-ai p-3.5 text-xs sm:text-sm max-w-lg leading-relaxed">
        ${escapeHtml(text)}
      </div>
    `;
  }

  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

function appendChatLoading(id) {
  const container = document.getElementById('chat-messages');
  const div = document.createElement('div');
  div.id = id;
  div.className = "flex items-start space-x-3";
  div.innerHTML = `
    <div class="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
      AI
    </div>
    <div class="chat-bubble-ai p-3 text-xs text-slate-400 flex items-center space-x-2">
      <i class="fa-solid fa-circle-notch fa-spin"></i>
      <span>Membaca dokumen Anda...</span>
    </div>
  `;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

function removeChatLoading(id) {
  const el = document.getElementById(id);
  if (el) el.remove();
}

function getFallbackChatReply(q) {
  const lower = q.toLowerCase();
  if (lower.includes('denda') || lower.includes('terlambat')) {
    return "Ya, dokumen ini menyebutkan adanya sanksi/denda jika terjadi keterlambatan pembayaran. Pastikan Anda memperhatikan tanggal jatuh tempo.";
  } else if (lower.includes('batal') || lower.includes('keluar') || lower.includes('resign')) {
    return "Pemutusan kontrak sebelum waktunya dapat memicu klausul ganti rugi atau deposit hangus. Sebaiknya kirim surat konfirmasi resmi 30 hari sebelumnya.";
  }
  return "Berdasarkan dokumen yang diringkas, seluruh aturan kewajiban telah tercantum. Sebaiknya simpan bukti pembayaran dan konfirmasi tertulis secara rapi.";
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
