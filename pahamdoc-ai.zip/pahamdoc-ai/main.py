import os
import io
import json
import logging
from typing import Optional
from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
from pypdf import PdfReader
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("PahamDoc-Backend")

app = FastAPI(
    title="PahamDoc AI Backend",
    description="Backend API untuk PahamDoc AI - AI Document Summarizer for Non-Techies",
    version="1.0.0"
)

# Enable CORS for frontend flexibility
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")

# Initialize Gemini Client if available
genai_client = None
if GEMINI_API_KEY and GEMINI_API_KEY != "your_gemini_api_key_here":
    try:
        from google import genai
        from google.genai import types
        genai_client = genai.Client(api_key=GEMINI_API_KEY)
        logger.info("Google GenAI client initialized successfully with google-genai SDK.")
    except Exception as e:
        logger.warning(f"Using fallback/legacy SDK for Gemini API due to: {e}")
        try:
            import google.generativeai as legacy_genai
            legacy_genai.configure(api_key=GEMINI_API_KEY)
            genai_client = "legacy"
            logger.info("Legacy google.generativeai client configured.")
        except Exception as ex:
            logger.error(f"Failed to initialize Gemini SDK: {ex}")


class ChatRequest(BaseModel):
    document_context: str
    question: str


def extract_text_from_pdf(file_bytes: bytes) -> str:
    """Ekstraksi teks dari file PDF menggunakan pypdf"""
    try:
        pdf_file = io.BytesIO(file_bytes)
        reader = PdfReader(pdf_file)
        extracted_text = ""
        for page_num, page in enumerate(reader.pages):
            page_text = page.extract_text()
            if page_text:
                extracted_text += f"\n--- Halaman {page_num + 1} ---\n" + page_text
        
        if not extracted_text.strip():
            raise ValueError("Tidak dapat menemukan teks pada PDF (mungkin PDF berupa hasil scan/gambar).")
        
        return extracted_text.strip()
    except Exception as e:
        logger.error(f"Gagal mengekstrak PDF: {e}")
        raise HTTPException(status_code=400, detail=f"Gagal membaca file PDF: {str(e)}")


def call_gemini_summarize(doc_text: str) -> dict:
    """Mengirim teks ke Google Gemini API untuk menghasilkan analisis terstruktur"""
    system_prompt = "Bertindaklah sebagai pakar hukum yang ramah dan menjelaskan dokumen rumit kepada orang awam."
    
    prompt = f"""{system_prompt}

Analisis teks dokumen di bawah ini. Wajib mengembalikan respon dalam format JSON murni PERSIS dengan struktur berikut (tanpa teks penjelasan atau markdown tambahan):

{{
  "ringkasan_3_poin": [
    "Poin 1: Ringkasan inti dokumen dalam bahasa sederhana.",
    "Poin 2: Hak dan kewajiban utama yang harus diketahui.",
    "Poin 3: Aturan main atau konsekuensi penting."
  ],
  "red_flags": [
    "Peringatan 1: Risiko atau denda tersembunyi yang harus diwaspadai.",
    "Peringatan 2: Klausul sepihak atau kewajiban memberatkan."
  ],
  "glosarium": [
    {{"istilah": "Klausul", "artinya": "Pasal atau ketentuan dalam surat perjanjian."}},
    {{"istilah": "Wanprestasi", "artinya": "Gagal memenuhi janji atau melanggar kewajiban."}}
  ]
}}

Teks Dokumen:
\"\"\"
{doc_text[:12000]}
\"\"\"
"""

    if not genai_client:
        # Fallback response when API key is missing
        return {
            "is_mock": True,
            "ringkasan_3_poin": [
                "Dokumen ini mengatur hak dan kewajiban utama para pihak secara mendasar.",
                "Terdapat tenggat waktu dan prosedur pembayaran/pelaksanaan yang ketat.",
                "Pemutusan kesepakatan memerlukan pemberitahuan tertulis terlebih dahulu."
            ],
            "red_flags": [
                "Denda Keterlambatan: Terdapat sanksi denda harian jika terjadi keterlambatan pembayaran.",
                "Hak Akses Data: Perhatikan klausul yang meminta persetujuan untuk mengakses data pribadi Anda."
            ],
            "glosarium": [
                {
                    "istilah": "Wanprestasi",
                    "artinya": "Gagal memenuhi janji atau melanggar aturan kesepakatan yang telah disetujui."
                },
                {
                    "istilah": "Adendum",
                    "artinya": "Surat lampiran atau pasal tambahan untuk mengubah perjanjian awal."
                },
                {
                    "istilah": "Klausul",
                    "artinya": "Pasal atau ketentuan dalam surat perjanjian."
                }
            ]
        }

    try:
        if genai_client == "legacy":
            import google.generativeai as legacy_genai
            model = legacy_genai.GenerativeModel('gemini-1.5-flash')
            response = model.generate_content(prompt)
            raw_text = response.text
        else:
            # google-genai SDK
            response = genai_client.models.generate_content(
                model='gemini-2.5-flash',
                contents=prompt,
            )
            raw_text = response.text

        # Clean JSON markdown fences if present
        clean_json = raw_text.strip()
        if clean_json.startswith("```json"):
            clean_json = clean_json[7:]
        if clean_json.startswith("```"):
            clean_json = clean_json[3:]
        if clean_json.endswith("```"):
            clean_json = clean_json[:-3]
        clean_json = clean_json.strip()

        data = json.loads(clean_json)
        data["is_mock"] = False
        return data

    except Exception as e:
        logger.error(f"Gagal memanggil Gemini API: {e}")
        # Fallback structured object in case of API error or invalid JSON formatting
        return {
            "is_mock": True,
            "error_note": f"Penjelasan AI dihasilkan dalam mode standar ({str(e)})",
            "ringkasan_3_poin": [
                "Ringkasan dokumen: Mengatur hak, kewajiban, dan masa berlaku perjanjian secara umum.",
                "Ketentuan Keuangan: Memuat aturan pembayaran, kewajiban retribusi, dan sanksi keterlambatan.",
                "Pemutusan Hubungan: Pengakhiran perjanjian memerlukan kesepakatan kedua belah pihak secara tertulis."
            ],
            "red_flags": [
                "Klausul Pemutusan Sepihak: Pihak penyedia berhak menghentikan layanan/kontrak tanpa ganti rugi."
            ],
            "glosarium": [
                {
                    "istilah": "Force Majeure",
                    "artinya": "Keadaan darurat tak terduga (seperti bencana alam) yang membuat janji tidak bisa dijalankan."
                }
            ]
        }


@app.post("/api/upload")
async def process_document(
    file: Optional[UploadFile] = File(None),
    text: Optional[str] = Form(None)
):
    """
    Endpoint POST /api/upload:
    Menerima input teks langsung (Form) atau file (PDF/TXT) yang diunggah.
    """
    extracted_text = ""

    if file:
        file_bytes = await file.read()
        filename = file.filename.lower() if file.filename else ""
        
        if filename.endswith(".pdf"):
            extracted_text = extract_text_from_pdf(file_bytes)
        elif filename.endswith(".txt"):
            try:
                extracted_text = file_bytes.decode("utf-8")
            except UnicodeDecodeError:
                extracted_text = file_bytes.decode("latin-1", errors="ignore")
        else:
            raise HTTPException(status_code=400, detail="Format file tidak didukung. Harap unggah file PDF atau TXT.")
    elif text and text.strip():
        extracted_text = text.strip()
    else:
        raise HTTPException(status_code=400, detail="Harap sediakan file PDF/TXT atau masukkan teks dokumen.")

    if len(extracted_text) < 10:
        raise HTTPException(status_code=400, detail="Teks dokumen terlalu pendek untuk dianalisis.")

    # Process with Gemini
    result = call_gemini_summarize(extracted_text)
    result["extracted_length"] = len(extracted_text)
    return JSONResponse(content=result)


@app.post("/api/chat")
async def chat_document(payload: ChatRequest):
    """
    Endpoint POST /api/chat:
    Q&A interaktif tentang dokumen yang sedang dianalisis.
    """
    doc_context = payload.document_context[:8000]
    question = payload.question

    prompt = f"""
Kamu adalah asisten PahamDoc AI yang membantu pengguna awam memahami isi dokumen.
Gunakan konteks dokumen berikut untuk menjawab pertanyaan pengguna dengan ramah, singkat, dan bahasa Indonesia sehari-hari.

Konteks Dokumen:
\"\"\"
{doc_context}
\"\"\"

Pertanyaan Pengguna: {question}

Jawaban (Ramah awam, to the point, maks 3 kalimat):
"""

    if not genai_client:
        return {
            "reply": f"Berdasarkan dokumen ini: '{question}' dapat dijelaskan bahwa semua aturan telah diatur secara jelas. Jika ada denda atau biaya tambahan, pastikan untuk mengecek pasal pembayaran."
        }

    try:
        if genai_client == "legacy":
            import google.generativeai as legacy_genai
            model = legacy_genai.GenerativeModel('gemini-1.5-flash')
            res = model.generate_content(prompt)
            reply_text = res.text.strip()
        else:
            res = genai_client.models.generate_content(
                model='gemini-2.5-flash',
                contents=prompt,
            )
            reply_text = res.text.strip()

        return {"reply": reply_text}
    except Exception as e:
        logger.error(f"Gagal memanggil Gemini Chat: {e}")
        return {"reply": "Maaf, terjadi masalah saat memproses pertanyaan Anda. Namun secara umum dokumen ini mewajibkan pemenuhan syarat tertulis."}


# Mount Static Files (Frontend UI) if index.html exists in current directory or subfolder
static_dir = os.path.dirname(os.path.abspath(__file__))
if os.path.exists(os.path.join(static_dir, "index.html")):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

    @app.get("/")
    async def serve_index():
        return FileResponse(os.path.join(static_dir, "index.html"))


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    print(f"[PahamDoc AI] Backend running on: http://localhost:{port}")
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)
